# Property Completeness

Version 0.01
Author: Rex Sang

# Overview:
compute property completeness